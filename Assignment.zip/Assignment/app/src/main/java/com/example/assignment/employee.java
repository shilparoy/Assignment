package com.example.assignment;




    public class employee {

        private String id , employee_name;
        private Double employee_salary;

        public employee(String id , String employee_name , Double salary){
            this.id = id;
            this.employee_name = employee_name;
            this.employee_salary = employee_salary;
        }

        public String getid() {
            return id;
        }

        public String getemployee_name() {
            return employee_name;
        }


        public Double getEmployee_salary() {
            return employee_salary;
        }
    }

