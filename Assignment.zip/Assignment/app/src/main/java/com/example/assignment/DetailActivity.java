
package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.TextView;


import com.example.assignment.R;

public class DetailActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_detail);



            TextView salary = findViewById(R.id.memployee_salary);
            TextView id = findViewById(R.id.mid);
            TextView employee_name = findViewById(R.id.memployee_name);

            Bundle bundle = getIntent().getExtras();

            String mid = bundle.getString("id");
            String memployee_name = bundle.getString("employee_name");
            double memployee_salary = bundle.getDouble("employee_salary");



            salary.setText(Double.toString(memployee_salary));
            id.setText(mid);
            employee_name.setText(memployee_name);

        }
    }

