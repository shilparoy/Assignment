package com.example.assignment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EmployeeAdapter extends RecyclerView.Adapter<EmployeeAdapter.EmployeeHolder> {

    private final Context context;
    private final List<employee> employeeList;

    public EmployeeAdapter(Context context,List<employee> employees){
        this.context = context;
        employeeList = employees;

    }
    @NonNull
    @Override
    public EmployeeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item , parent , false);
        return  new EmployeeHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull EmployeeHolder holder, int position) {
        employee employee = employeeList.get(position);
        holder.salary.setText(employee.getEmployee_salary().toString());
        holder.id.setText(employee.getid());
        holder.employee_name.setText(employee.getemployee_name());


        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context , com.example.assignment.DetailActivity.class);

                Bundle bundle = new Bundle();
                bundle.putString("id" , employee.getid());
                bundle.putString("employee_name" , employee.getemployee_name());
                bundle.putDouble("salary" , employee.getEmployee_salary());

                intent.putExtras(bundle);

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return employeeList.size();
    }

    public class EmployeeHolder extends RecyclerView.ViewHolder{
        public View constraintLayout;
        TextView id,employee_name,salary;
        public EmployeeHolder(@NonNull View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.id);
            employee_name = itemView.findViewById(R.id.employee_name);
            salary = itemView.findViewById(R.id.employee_salary);
        }
    }
}
