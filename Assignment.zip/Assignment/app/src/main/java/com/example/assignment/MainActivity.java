package com.example.assignment;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RequestQueue requestQueue;
    private List<employee> employeeList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        requestQueue = VolleySingleton.getmInstance(this).getRequestQueue();

        employeeList = new ArrayList<>();
        fetchemployee();


    }

    private void fetchemployee() {

        String query_url_Get_all = "https://dummy.restapiexample.com/api/v1/employees";

        String query_url_Get_one = "https://jsonplaceholder.typicode.com/todos/1";
        try {
            URL url = new URL(query_url_Get_one);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                ; throw new RuntimeException("Failed : HTTP error code :"
                        + conn.getResponseCode());
            }




         //   System.out.println("Output from server..../n");

            /* String output; */
            String output = "";
            while ((new String(output) != null)) {
                System.out.println(output);
            }
            conn.disconnect();


        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        String url ="https://dummy.restapiexample.com/api/v1/employees";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET,url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        for (int i = 0 ; i < response.length() ; i ++){
                            try {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String id = jsonObject.getString("id");
                                String employee_name = jsonObject.getString("employee_name");
                                Double employee_salary = jsonObject.getDouble("employee_salary");

                                employee employee = new employee(id , employee_name , employee_salary);
                                employeeList.add(employee);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            EmployeeAdapter adapter = new EmployeeAdapter(MainActivity.this , employeeList);

                            recyclerView.setAdapter(adapter);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(jsonArrayRequest);
    }
}