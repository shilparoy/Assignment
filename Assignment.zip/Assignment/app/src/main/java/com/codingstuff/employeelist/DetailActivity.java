package com.codingstuff.employeelist;

public class DetailActivity {
}
